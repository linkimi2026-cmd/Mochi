// mochi-documents · 教师侧受控结构化文档工具入口。
//
// The renderer in index.mjs owns document validation, atomic publication, and
// cancellation cleanup. This adapter owns only the Alpha tool contract and a
// session-bound output location; a model never chooses a host filesystem path.
import { randomUUID } from 'node:crypto';
import { lstat, mkdir, realpath } from 'node:fs/promises';
import { isAbsolute, join, relative, resolve, sep } from 'node:path';
import { defineTool } from '@deepseek-ai/dsh-tools';
import { generateDocumentBundle, MochiDocumentsError, validateStructuredDocument } from './index.mjs';

export const name = 'mochi-documents';
export const inject = ['tools', 'sandboxPolicy'];

// dsh-tools invokes render(args, value). Keeping both arguments prevents a
// replay/render call from serialising its input in place of the real result.
export const output = {
  schema: { type: 'object', additionalProperties: true },
  render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
};

const OUTPUT_PARENT_NAME = 'Mochi Documents';
const GENERIC_TEMPLATE = 'generic';
const SICHUAN_2026_EXAM_TEMPLATE = 'sichuan-2026-high-school-exam-base';

export class MochiDocumentsToolError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'MochiDocumentsToolError';
    this.code = code;
  }
}

function toolFailure(code, message) {
  return new MochiDocumentsToolError(code, message);
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw toolFailure('ABORTED', '文档生成已取消；未发布任何完成文档。');
}

function isDescendant(parent, candidate) {
  const difference = relative(parent, candidate);
  return difference === '' || (!difference.startsWith(`..${sep}`) && difference !== '..' && !isAbsolute(difference));
}

async function ordinaryDirectory(path, label) {
  let info;
  try {
    info = await lstat(path);
  } catch (error) {
    if (error?.code === 'ENOENT') throw toolFailure('WORKSPACE_UNAVAILABLE', `${label}不存在，无法安全生成文档。`);
    throw toolFailure('WORKSPACE_UNAVAILABLE', `${label}不可访问，无法安全生成文档。`);
  }
  if (!info.isDirectory() || info.isSymbolicLink()) {
    throw toolFailure('WORKSPACE_UNSAFE', `${label}必须是普通目录，不能使用符号链接。`);
  }
}

async function createOutputDirectory(ctx, exec) {
  throwIfAborted(exec?.signal);
  const session = exec?.agent?.session;
  const sessionWorkspace = session?.header?.cwd;
  if (!session || typeof sessionWorkspace !== 'string' || !isAbsolute(sessionWorkspace)) {
    throw toolFailure('SESSION_WORKSPACE_REQUIRED', '只能在具有受管工作区的当前会话中生成文档。');
  }
  if (!ctx?.sandboxPolicy || typeof ctx.sandboxPolicy.resolve !== 'function') {
    throw toolFailure('SANDBOX_POLICY_UNAVAILABLE', '当前宿主未提供文档输出所需的工作区权限策略。');
  }

  const policy = ctx.sandboxPolicy.resolve({ session });
  if (policy?.mode === 'read-only') {
    throw toolFailure('SANDBOX_READ_ONLY', '当前会话是只读模式；请按宿主审批流程切换到可写工作区后再生成文档。');
  }
  if (typeof policy?.workspaceRoot !== 'string' || !isAbsolute(policy.workspaceRoot)) {
    throw toolFailure('WORKSPACE_UNAVAILABLE', '宿主没有提供有效的受管工作区。');
  }

  // Resolve the session-specific policy for every call. We deliberately keep
  // all output within this root even in danger-full-access mode.
  const requestedWorkspace = resolve(policy.workspaceRoot);
  await ordinaryDirectory(requestedWorkspace, '会话工作区');
  const workspaceRoot = await realpath(requestedWorkspace);
  await ordinaryDirectory(workspaceRoot, '会话工作区');

  const outputParent = join(workspaceRoot, OUTPUT_PARENT_NAME);
  try {
    await mkdir(outputParent, { mode: 0o700 });
  } catch (error) {
    if (error?.code !== 'EEXIST') {
      throw toolFailure('WORKSPACE_UNAVAILABLE', '无法在受管工作区创建文档输出目录。');
    }
  }
  await ordinaryDirectory(outputParent, '文档输出目录');
  const canonicalOutputParent = await realpath(outputParent);
  if (!isDescendant(workspaceRoot, canonicalOutputParent)) {
    throw toolFailure('WORKSPACE_UNSAFE', '文档输出目录不在当前会话工作区内。');
  }
  throwIfAborted(exec?.signal);

  // This name is host-generated. The input schema has no filesystem field and
  // cannot influence it; the renderer reserves it atomically a second time.
  return join(canonicalOutputParent, `document-${randomUUID()}`);
}

function rethrowDocumentError(error) {
  if (error instanceof MochiDocumentsToolError) throw error;
  if (!(error instanceof MochiDocumentsError)) throw error;
  const messages = {
    ABORTED: '文档生成已取消；未发布任何完成文档。',
    INVALID_INPUT: '文档结构不合法：请按结构化页面、段落、表格和疑点格式补全后重试。',
    OUTPUT_EXISTS: '宿主生成的输出目录已被占用；请重新发起生成，旧文件不会被覆盖。',
    INVALID_OUTPUT_DIRECTORY: '宿主未提供有效的受管输出目录。',
    GENERATION_FAILED: '文档在完成发布前生成失败；没有可用的完成文档。',
  };
  throw toolFailure(error.code, messages[error.code] ?? `文档生成失败（${error.code}）。`);
}

function genericOnly(document) {
  if (document.template.kind === GENERIC_TEMPLATE) return;
  if (document.template.kind === SICHUAN_2026_EXAM_TEMPLATE) {
    throw toolFailure(
      'SPECIAL_TEMPLATE_UNAVAILABLE',
      '四川 2026 考试模板当前不在教师工具中开放：它需要受管本机 LibreOffice、macOS 宋体/Times 字体与单独印刷核验；本次没有调用任何 Office 转换程序。请改用普通结构化文档模板。',
    );
  }
  throw toolFailure('SPECIAL_TEMPLATE_UNAVAILABLE', '当前教师工具只开放普通结构化文档模板。');
}

function bundleResult(document, bundle) {
  return {
    状态: '已完成',
    工具: 'mochi.document_create',
    标题: document.title,
    模板: '普通结构化文档',
    输出目录: bundle.outputDirectory,
    产物: {
      可编辑DOCX: bundle.docxPath,
      嵌字PDF: bundle.pdfPath,
      疑点清单: bundle.questionsPath,
      检查清单: bundle.checklistPath,
      完成标志: bundle.manifestPath,
    },
    检查: bundle.manifest.files,
    完成标志状态: bundle.manifest.status,
    说明: '已在当前会话的受管工作区新建目录中生成可编辑 DOCX、同源结构化 PDF、疑点与检查清单；不会覆盖旧版本。',
  };
}

function parameterSchema() {
  // validateStructuredDocument is the authoritative deep validator. The tool
  // schema only provides the fixed-alpha type boundary and has no output path.
  return {
    sourceKind: {
      type: 'string',
      required: true,
      enum: ['upstream-authorized-structured-content', 'demonstration'],
      description: '已获授权的结构化来源类型。',
    },
    title: { type: 'string', required: true, description: '文档标题。' },
    sourceLabel: { type: 'string', description: '可选来源标签。' },
    template: {
      type: 'string',
      enum: [GENERIC_TEMPLATE, SICHUAN_2026_EXAM_TEMPLATE],
      description: '默认 generic。当前教师工具仅执行 generic；特殊考试模板会如实说明其本机依赖限制。',
    },
    pages: {
      type: 'array',
      items: { type: 'json' },
      description: '普通模板页面，例如 [{blocks:[{kind:"heading",level:1,text:"标题"},{kind:"paragraph",text:"正文"},{kind:"table",columns:["项目","安排"],rows:[["讨论","观察现象"]]}]}]。heading 的 level 是 1 或 2；paragraph 有 text；table 必须有 columns 和每行列数相同的 rows。',
    },
    doubts: {
      type: 'array',
      items: { type: 'json' },
      description: '可选待核对事项：{question, source:{kind:"unknown"}} 或归一化页区。',
    },
    exam: {
      type: 'json',
      description: '仅四川考试模板的现有结构；当前工具不会运行该特殊模板。',
    },
  };
}

export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'mochi.document_create',
    description: '把已获授权的结构化教学内容生成到当前会话工作区中的全新受管目录：返回可编辑 DOCX、同源结构化 PDF、疑点清单和检查清单。只接受标题、页面块、真实表格与疑点结构；不接受图片替代、任意本机路径、URL、OCR 或任意 Office 转换请求。普通模板不启动外部程序。',
    parameters: parameterSchema(),
    output,
    execute: async (args, exec) => {
      let document;
      try {
        throwIfAborted(exec?.signal);
        document = validateStructuredDocument(args);
        genericOnly(document);
        const outputDirectory = await createOutputDirectory(ctx, exec);
        const bundle = await generateDocumentBundle({
          // The renderer deliberately validates the original wire shape. The
          // prevalidated value has template:{kind:"generic"}, which is an
          // internal normalized form and must not be fed into that validator.
          document: args,
          outputDirectory,
          signal: exec?.signal,
        });
        return bundleResult(document, bundle);
      } catch (error) {
        rethrowDocumentError(error);
      }
    },
  }));
}
