import { installLanHostBridge } from './host-bridge.mjs';
import { MochiLanService } from './lan-service.mjs';

export const name = 'mochi-lan';

/**
 * The LAN service deliberately starts without a model turn. Its settings and
 * inbox are reached through Connection's authenticated local routes, while
 * teacher-originated notifications are registered by mochi-dispatch and still
 * pass through the official approval waterfall.
 */
export function apply(ctx, config = {}) {
  const lan = new MochiLanService({
    ...(config.dataRoot === undefined ? {} : { dataRoot: config.dataRoot }),
    ...(config.bindHost === undefined ? {} : { bindHost: config.bindHost }),
    ...(config.port === undefined ? {} : { port: config.port }),
    ...(config.discoveryEnabled === undefined ? {} : { discoveryEnabled: config.discoveryEnabled }),
    ...(config.discoveryPort === undefined ? {} : { discoveryPort: config.discoveryPort }),
    ...(config.lockedRole === undefined && config.role === undefined ? {} : { lockedRole: config.lockedRole ?? config.role }),
    ...(config.identity === undefined ? {} : { identity: config.identity }),
  });
  ctx.provide('mochiLan', lan);
  ctx.inject(['connection'], (hostCtx) => installLanHostBridge(hostCtx, lan));
  // Cordis treats a returned promise as an effect whose resolved value must be
  // a disposer. Returning the raw snapshot from lan.start() would therefore
  // mark the plugin active before startup completed. Bind startup and cleanup
  // as one lifecycle effect instead.
  return lan.start().then(() => () => lan.stop());
}
