export const name = 'mochi-hello';

export function apply(ctx) {
  console.log('[Mochi] hello plugin loaded! 内核已挂载自定义插件');
  if (ctx.logger?.info) ctx.logger.info('[mochi-hello] apply() 被调用');
}
