import type { SessionFormatArtifact, SessionFormatHeader } from '@deepseek-ai/dsh-session-format';
/**
 * Validate the exact logical header written by released v2.
 * @param header - decoded released-v2 Session header.
 * @throws {SessionFormatError} when the header is not an exact released-v2 value.
 */
export declare function assertReleasedV2Header(header: SessionFormatHeader): void;
/**
 * Validate the exact logical image emitted by the released v2 writer.
 * @param artifact - complete decoded released-v2 Session artifact.
 * @throws {SessionFormatError} when an envelope, payload, relationship, or inherited cut is invalid.
 * @throws {SessionFormatUnsupportedMigrationError} when the artifact contains an unknown event type.
 */
export declare function assertReleasedV2Artifact(artifact: SessionFormatArtifact): void;
/**
 * Validate only the released-v2 physical header, event envelopes, and inherited cut.
 * Event vocabulary and payload semantics belong to target or installed-current restoration.
 * @param artifact - complete physical-codec output.
 */
export declare function assertReleasedV2PhysicalArtifact(artifact: SessionFormatArtifact): void;
/**
 * Restore and validate one decoded released-v2 artifact.
 * @param artifact - detached vocabulary-restored artifact.
 * @param knownEventTypes - event types understood by the installed current Session package.
 * @returns the same validated artifact.
 */
export declare function restoreReleasedV2Artifact(artifact: SessionFormatArtifact, knownEventTypes: ReadonlySet<string>): SessionFormatArtifact;
//# sourceMappingURL=validation.d.ts.map