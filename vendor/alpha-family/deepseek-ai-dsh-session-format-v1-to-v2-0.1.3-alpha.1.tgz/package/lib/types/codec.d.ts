import type { EncodedSessionFormatArtifact, SessionFormatArtifact, SessionFormatHeader } from '@deepseek-ai/dsh-session-format';
/** Frozen physical JSON codec for released v2. */
export declare const releasedV2SessionFormatCodec: Readonly<{
    version: number;
    decodeHeader(value: unknown): SessionFormatHeader;
    decodeArtifact(headerValue: unknown, rowValues: readonly unknown[]): SessionFormatArtifact;
    decodeRecoverableArtifact(headerValue: unknown, rowValues: readonly unknown[]): SessionFormatArtifact;
    encodeArtifact(artifact: SessionFormatArtifact): EncodedSessionFormatArtifact;
}>;
//# sourceMappingURL=codec.d.ts.map