/**
 * Durable whole-generation publication for JSONL Session artifacts.
 *
 * Format packages transform parsed JSON values. This module owns the physical
 * encoding, exact source identity, immutable generation files, and exclusive
 * current-generation publication for both configured JSONL suffixes.
 * @module @deepseek-ai/dsh-session-persistence-jsonl/generation
 */
import { type FileHandle } from 'node:fs/promises';
import type { JsonlCompression } from './format.ts';
import { publishNewFileWin32 } from './win32.ts';
/** Parsed JSONL values supplied to the format catalog. */
export interface JsonlDecodedGeneration {
    readonly header: Record<string, unknown>;
    readonly rows: readonly unknown[];
}
/** Current JSONL values returned by the format catalog for physical encoding. */
export interface JsonlCurrentGeneration extends JsonlDecodedGeneration {
}
/** Pure adapter between backend-owned JSONL framing and the format catalog. */
export interface JsonlGenerationFormatAdapter {
    readonly currentVersion: number;
    /** Convert one detached historical generation to exact current JSON values. */
    migrate(source: JsonlDecodedGeneration): JsonlCurrentGeneration;
    /** Validate one decoded current generation, including after committed reopen. */
    validateCurrent(candidate: JsonlCurrentGeneration): void;
    /** Classify a supported-version artifact that policy refuses to migrate. */
    isUnsupportedMigrationError?(error: unknown): error is Error;
}
/** Inputs for ensuring one already-resolved generation has a current successor. */
export interface EnsureJsonlGenerationOptions {
    /** Immutable generation selected by the backend resolver. */
    readonly sourcePath: string;
    /** Version selected from the source filename and independently checked against its header. */
    readonly sourceVersion: number;
    /** Canonical filename for `format.currentVersion` in the same Session directory. */
    readonly currentPath: string;
    readonly compression: JsonlCompression;
    readonly format: JsonlGenerationFormatAdapter;
    /** Validate one selected historical header's identity before any migration write. */
    readonly validateHistoricalHeader?: (header: Readonly<Record<string, unknown>>) => void | Promise<void>;
    readonly signal?: AbortSignal;
}
/** Result of current classification or exclusive publication. */
export type EnsureJsonlGenerationResult = {
    readonly status: 'current';
    readonly version: number;
    readonly path: string;
    readonly snapshot: JsonlPhysicalSnapshot;
} | {
    readonly status: 'migrated';
    readonly fromVersion: number;
    readonly toVersion: number;
    readonly path: string;
    readonly sourcePath: string;
    readonly snapshot: JsonlPhysicalSnapshot;
};
/** A future physical header was readable, but this writer cannot interpret it. */
export declare class JsonlGenerationNewerVersionError extends Error {
    readonly storedVersion: number;
    readonly currentVersion: number;
    readonly storedId: string;
    readonly name = "JsonlGenerationNewerVersionError";
    /**
     * @param storedVersion - version read from the highest stored generation.
     * @param currentVersion - version this build writes.
     * @param storedId - minimally decoded identity used in the refusal diagnostic.
     */
    constructor(storedVersion: number, currentVersion: number, storedId: string);
}
/** A historical artifact is intact, but the format edge refuses its contents. */
export declare class JsonlGenerationUnsupportedMigrationError extends Error {
    readonly fromVersion: number;
    readonly reason: Error;
    readonly name = "JsonlGenerationUnsupportedMigrationError";
    /**
     * @param fromVersion - unchanged source generation version.
     * @param reason - format-edge refusal.
     */
    constructor(fromVersion: number, reason: Error);
}
/** A current-generation filename already names different or invalid bytes. */
export declare class JsonlGenerationTargetConflictError extends Error {
    readonly path: string;
    readonly reason: Error;
    readonly name = "JsonlGenerationTargetConflictError";
    /**
     * @param path - immutable target that prevented exclusive publication.
     * @param reason - why the existing target cannot be accepted.
     */
    constructor(path: string, reason: Error);
}
/** Stat identity captured together with exact generation bytes. */
export interface JsonlPhysicalIdentity {
    readonly dev: bigint;
    readonly ino: bigint;
    readonly size: bigint;
    readonly mtimeNs: bigint;
    readonly ctimeNs: bigint;
}
/** One revision-stable physical artifact read reusable by the immediate backend hook. */
export interface JsonlPhysicalSnapshot {
    readonly bytes: Buffer;
    readonly identity: JsonlPhysicalIdentity;
    readonly headerValue: Record<string, unknown>;
    readonly headerRecord: Buffer;
}
/** Exact bytes of one stable file revision together with the stat identity that proved it stable. */
export interface StablePhysicalFile {
    readonly bytes: Buffer;
    readonly identity: JsonlPhysicalIdentity;
}
interface GenerationFileSystem {
    open(path: string, flags: string, mode?: number): Promise<FileHandle>;
    readFile(path: string, signal?: AbortSignal): Promise<Buffer>;
    readdir(path: string): Promise<string[]>;
    stat(path: string): Promise<JsonlPhysicalIdentity>;
    lstat(path: string): Promise<{
        isFile(): boolean;
        isSymbolicLink(): boolean;
    }>;
    link(existingPath: string, newPath: string): Promise<void>;
    rm(path: string): Promise<void>;
}
type GenerationBarrierPhase = 'before-source-check' | 'after-publication';
interface JsonlGenerationInternals {
    readonly fs: GenerationFileSystem;
    readonly randomToken: () => string;
    readonly platform: NodeJS.Platform;
    readonly publishNewWin32: typeof publishNewFileWin32;
    readonly barrier: (phase: GenerationBarrierPhase, attempt: number) => void | Promise<void>;
}
type JsonlGenerationTestOverrides = Partial<Omit<JsonlGenerationInternals, 'fs'>> & {
    readonly fs?: Partial<GenerationFileSystem>;
};
/**
 * Read one stable revision of a JSONL file with a single retry. If an append
 * overlaps both reads, return the second read's committed pre-read prefix
 * instead of starving behind a continuous writer.
 * @param path - the generation file to read.
 * @param signal - optional cancellation for the stat/read work.
 * @returns the stable bytes (or the committed prefix) and their stat identity.
 */
export declare function readStableJsonlFile(path: string, signal?: AbortSignal): Promise<StablePhysicalFile>;
/**
 * Ensure one resolved generation has a current-format successor. Current input reads one
 * coherent physical snapshot, inspects only its independently readable header,
 * invokes no body decoder or migration callback, and returns that snapshot for
 * the immediate body-reading backend hook. Historical input remains unchanged;
 * only a previously absent current filename can be published.
 * @param options - resolved source and target, configured encoding, format adapter, and cancellation.
 * @returns whether the source was already current or which immutable successor was published.
 */
export declare function ensureJsonlGenerationCurrent(options: EnsureJsonlGenerationOptions): Promise<EnsureJsonlGenerationResult>;
/** Private deterministic filesystem, platform, and race seams for package tests. */
export declare const __jsonlGenerationTest: {
    ensure(options: EnsureJsonlGenerationOptions, overrides: JsonlGenerationTestOverrides): Promise<EnsureJsonlGenerationResult>;
};
export {};
//# sourceMappingURL=generation.d.ts.map